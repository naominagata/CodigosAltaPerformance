package exercicio03;

import java.util.Scanner;

import filas.FilasString;

public class Exercicio03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		FilasString fila = new FilasString();
		
		fila.init();
		
		int opcao;
		
		do {
			System.out.println("1- Inserir paciente");
			System.out.println("2- Chamar paciente");
			System.out.println("3- Encerrar");
			System.out.println("Op��o: ");
			opcao = teclado.nextInt();
			switch (opcao) {
			case 1: 
				System.out.println("Inserir o nome do paciente: ");
				String nome = teclado.next();
				fila.enqueue(nome); //inserir
				break;
			case 2: 
				if (!fila.isEmpty())
			        System.out.println("Paciente chamado para atendimento" + fila.dequeue());
				break;
			case 3: 
				if (!fila.isEmpty())
					System.out.println("Ainda h� pacientes na fila");
				opcao = 0; //faz ele voltar para menu de opcoes
				break;
		    default:
		    	System.out.println("Op��o invalida");
			}
		} while (opcao != 3);
		
		System.out.println("Atendimento encerrado");
		
	}
}
