package exercicio01;

import java.util.Scanner;

import filas.FilasInt;

public class Exercicio01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		FilasInt fila = new FilasInt(); //instanciar fila
		fila.init(); //chamando ini = fim = null
		
		System.out.println("Digite um numero positivo ou negativo para sair");
		int valor = teclado.nextInt();
		
		while (valor >= 0) {
			fila.enqueue(valor); //insere na fila o valor digitado
			System.out.println("Digite um numero positivo ou negativo para sair");
			valor = teclado.nextInt();
		}
		
		while (!fila.isEmpty())
			System.out.println("Valor retirado: " + fila.dequeue());
		
	}

}
